﻿namespace CarRental
{
    partial class Signin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Signin));
            this.panelSigninImage = new MetroFramework.Controls.MetroPanel();
            this.panelSignin = new MetroFramework.Controls.MetroPanel();
            this.labelSignin = new System.Windows.Forms.Label();
            this.labelName = new System.Windows.Forms.Label();
            this.textName = new System.Windows.Forms.TextBox();
            this.labelDesignation = new System.Windows.Forms.Label();
            this.textPassword = new System.Windows.Forms.TextBox();
            this.labelPassword = new System.Windows.Forms.Label();
            this.textEmail = new System.Windows.Forms.TextBox();
            this.labelEmail = new System.Windows.Forms.Label();
            this.radioButtonManager = new System.Windows.Forms.RadioButton();
            this.radioButtonCustomer = new System.Windows.Forms.RadioButton();
            this.buttonSignin = new MetroFramework.Controls.MetroButton();
            this.panelSigninImage.SuspendLayout();
            this.panelSignin.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelSigninImage
            // 
            this.panelSigninImage.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panelSigninImage.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panelSigninImage.BackgroundImage")));
            this.panelSigninImage.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panelSigninImage.Controls.Add(this.panelSignin);
            this.panelSigninImage.HorizontalScrollbarBarColor = true;
            this.panelSigninImage.HorizontalScrollbarHighlightOnWheel = false;
            this.panelSigninImage.HorizontalScrollbarSize = 10;
            this.panelSigninImage.Location = new System.Drawing.Point(-7, 28);
            this.panelSigninImage.Name = "panelSigninImage";
            this.panelSigninImage.Size = new System.Drawing.Size(1143, 753);
            this.panelSigninImage.TabIndex = 0;
            this.panelSigninImage.UseCustomBackColor = true;
            this.panelSigninImage.VerticalScrollbarBarColor = true;
            this.panelSigninImage.VerticalScrollbarHighlightOnWheel = false;
            this.panelSigninImage.VerticalScrollbarSize = 10;
            // 
            // panelSignin
            // 
            this.panelSignin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.panelSignin.Controls.Add(this.buttonSignin);
            this.panelSignin.Controls.Add(this.radioButtonCustomer);
            this.panelSignin.Controls.Add(this.radioButtonManager);
            this.panelSignin.Controls.Add(this.textEmail);
            this.panelSignin.Controls.Add(this.labelEmail);
            this.panelSignin.Controls.Add(this.textPassword);
            this.panelSignin.Controls.Add(this.labelPassword);
            this.panelSignin.Controls.Add(this.labelDesignation);
            this.panelSignin.Controls.Add(this.textName);
            this.panelSignin.Controls.Add(this.labelName);
            this.panelSignin.Controls.Add(this.labelSignin);
            this.panelSignin.HorizontalScrollbarBarColor = true;
            this.panelSignin.HorizontalScrollbarHighlightOnWheel = false;
            this.panelSignin.HorizontalScrollbarSize = 10;
            this.panelSignin.Location = new System.Drawing.Point(316, 78);
            this.panelSignin.Name = "panelSignin";
            this.panelSignin.Size = new System.Drawing.Size(490, 612);
            this.panelSignin.TabIndex = 2;
            this.panelSignin.UseCustomBackColor = true;
            this.panelSignin.UseCustomForeColor = true;
            this.panelSignin.VerticalScrollbarBarColor = true;
            this.panelSignin.VerticalScrollbarHighlightOnWheel = false;
            this.panelSignin.VerticalScrollbarSize = 10;
            // 
            // labelSignin
            // 
            this.labelSignin.AutoSize = true;
            this.labelSignin.BackColor = System.Drawing.Color.Transparent;
            this.labelSignin.Font = new System.Drawing.Font("Myanmar Text", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSignin.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.labelSignin.Location = new System.Drawing.Point(186, 50);
            this.labelSignin.Name = "labelSignin";
            this.labelSignin.Size = new System.Drawing.Size(136, 60);
            this.labelSignin.TabIndex = 3;
            this.labelSignin.Text = "Sign in";
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.BackColor = System.Drawing.Color.Transparent;
            this.labelName.Font = new System.Drawing.Font("Myanmar Text", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelName.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.labelName.Location = new System.Drawing.Point(101, 190);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(68, 30);
            this.labelName.TabIndex = 3;
            this.labelName.Text = "Name :";
            // 
            // textName
            // 
            this.textName.Location = new System.Drawing.Point(217, 190);
            this.textName.Multiline = true;
            this.textName.Name = "textName";
            this.textName.Size = new System.Drawing.Size(211, 26);
            this.textName.TabIndex = 3;
            // 
            // labelDesignation
            // 
            this.labelDesignation.AutoSize = true;
            this.labelDesignation.BackColor = System.Drawing.Color.Transparent;
            this.labelDesignation.Font = new System.Drawing.Font("Myanmar Text", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelDesignation.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.labelDesignation.Location = new System.Drawing.Point(101, 298);
            this.labelDesignation.Name = "labelDesignation";
            this.labelDesignation.Size = new System.Drawing.Size(113, 30);
            this.labelDesignation.TabIndex = 5;
            this.labelDesignation.Text = "Designation :";
            // 
            // textPassword
            // 
            this.textPassword.Location = new System.Drawing.Point(217, 354);
            this.textPassword.Multiline = true;
            this.textPassword.Name = "textPassword";
            this.textPassword.Size = new System.Drawing.Size(211, 26);
            this.textPassword.TabIndex = 6;
            // 
            // labelPassword
            // 
            this.labelPassword.AutoSize = true;
            this.labelPassword.BackColor = System.Drawing.Color.Transparent;
            this.labelPassword.Font = new System.Drawing.Font("Myanmar Text", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPassword.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.labelPassword.Location = new System.Drawing.Point(101, 354);
            this.labelPassword.Name = "labelPassword";
            this.labelPassword.Size = new System.Drawing.Size(93, 30);
            this.labelPassword.TabIndex = 7;
            this.labelPassword.Text = "Password :";
            // 
            // textEmail
            // 
            this.textEmail.Location = new System.Drawing.Point(217, 243);
            this.textEmail.Multiline = true;
            this.textEmail.Name = "textEmail";
            this.textEmail.Size = new System.Drawing.Size(211, 26);
            this.textEmail.TabIndex = 8;
            // 
            // labelEmail
            // 
            this.labelEmail.AutoSize = true;
            this.labelEmail.BackColor = System.Drawing.Color.Transparent;
            this.labelEmail.Font = new System.Drawing.Font("Myanmar Text", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelEmail.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.labelEmail.Location = new System.Drawing.Point(101, 243);
            this.labelEmail.Name = "labelEmail";
            this.labelEmail.Size = new System.Drawing.Size(63, 30);
            this.labelEmail.TabIndex = 9;
            this.labelEmail.Text = "Email :";
            // 
            // radioButtonManager
            // 
            this.radioButtonManager.AutoSize = true;
            this.radioButtonManager.BackColor = System.Drawing.Color.Transparent;
            this.radioButtonManager.Font = new System.Drawing.Font("Myanmar Text", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonManager.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.radioButtonManager.Location = new System.Drawing.Point(217, 294);
            this.radioButtonManager.Name = "radioButtonManager";
            this.radioButtonManager.Size = new System.Drawing.Size(102, 34);
            this.radioButtonManager.TabIndex = 11;
            this.radioButtonManager.TabStop = true;
            this.radioButtonManager.Text = "Manager";
            this.radioButtonManager.UseVisualStyleBackColor = false;
            // 
            // radioButtonCustomer
            // 
            this.radioButtonCustomer.AutoSize = true;
            this.radioButtonCustomer.BackColor = System.Drawing.Color.Transparent;
            this.radioButtonCustomer.Font = new System.Drawing.Font("Myanmar Text", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonCustomer.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.radioButtonCustomer.Location = new System.Drawing.Point(337, 294);
            this.radioButtonCustomer.Name = "radioButtonCustomer";
            this.radioButtonCustomer.Size = new System.Drawing.Size(108, 34);
            this.radioButtonCustomer.TabIndex = 12;
            this.radioButtonCustomer.TabStop = true;
            this.radioButtonCustomer.Text = "Customer";
            this.radioButtonCustomer.UseVisualStyleBackColor = false;
            // 
            // buttonSignin
            // 
            this.buttonSignin.BackColor = System.Drawing.Color.Transparent;
            this.buttonSignin.FontSize = MetroFramework.MetroButtonSize.Tall;
            this.buttonSignin.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.buttonSignin.Location = new System.Drawing.Point(130, 446);
            this.buttonSignin.Name = "buttonSignin";
            this.buttonSignin.Size = new System.Drawing.Size(268, 44);
            this.buttonSignin.TabIndex = 13;
            this.buttonSignin.Text = "Sign In";
            this.buttonSignin.UseCustomBackColor = true;
            this.buttonSignin.UseCustomForeColor = true;
            this.buttonSignin.UseSelectable = true;
            // 
            // Signin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1078, 779);
            this.Controls.Add(this.panelSigninImage);
            this.MaximizeBox = false;
            this.Name = "Signin";
            this.Style = MetroFramework.MetroColorStyle.Black;
            this.panelSigninImage.ResumeLayout(false);
            this.panelSignin.ResumeLayout(false);
            this.panelSignin.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroPanel panelSigninImage;
        private MetroFramework.Controls.MetroPanel panelSignin;
        private System.Windows.Forms.Label labelSignin;
        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.RadioButton radioButtonCustomer;
        private System.Windows.Forms.RadioButton radioButtonManager;
        private System.Windows.Forms.TextBox textEmail;
        private System.Windows.Forms.Label labelEmail;
        private System.Windows.Forms.TextBox textPassword;
        private System.Windows.Forms.Label labelPassword;
        private System.Windows.Forms.Label labelDesignation;
        private System.Windows.Forms.TextBox textName;
        private MetroFramework.Controls.MetroButton buttonSignin;
    }
}